import 'package:bmi_caculator/layout/home_layout.dart';
import 'package:bmi_caculator/modules/bmi/bmi_screen.dart';
import 'package:bmi_caculator/modules/login/login_screen.dart';
import 'package:flutter/material.dart';

import 'modules/bmi_result/bmi_result_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomeLayout(),
    );
  }
}


